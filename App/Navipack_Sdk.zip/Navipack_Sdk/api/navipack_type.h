/**
******************************************************************************
* @file    navipack_type.h
* @author  *
* @date    *
* @brief   用于引入和定义需要的数据类型
* @attention Copyright (C) 
******************************************************************************
*/
#ifndef __NAVIPACK_TYPE_H__
#define __NAVIPACK_TYPE_H__

// 引入需要的类型定义
#include "mcu_lib.h"

#endif
